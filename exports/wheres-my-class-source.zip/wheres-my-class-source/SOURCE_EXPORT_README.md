# Where’s My Class? — Source Export

This archive contains the complete project source for the Where’s My Class? web app, including the React/Vite artifact, shared workspace libraries, API/database scaffolding, configuration files, typed class data, and the original attached reference files.

## Run the web app locally

From the repository root:

```bash
pnpm install
PORT=5173 BASE_PATH=/ pnpm --filter @workspace/wheres-my-class run dev
```

Then open the Vite URL printed in the terminal.

## Typecheck and build

```bash
pnpm --filter @workspace/wheres-my-class run typecheck
PORT=5173 BASE_PATH=/ pnpm --filter @workspace/wheres-my-class run build
```

## Source map

- `artifacts/wheres-my-class/` — the Where’s My Class? React/Vite frontend artifact
- `artifacts/wheres-my-class/src/App.tsx` — app flow, lookup, dashboard, timetable, and reminders
- `artifacts/wheres-my-class/src/data/classData.ts` — typed institution, branch, student, timetable, and time-engine data
- `artifacts/wheres-my-class/src/index.css` — responsive styles, theme, and motion
- `lib/` — shared workspace libraries, API contracts/client generation, and database scaffolding
- `artifacts/api-server/` — shared API server scaffold
- `attached_assets/` — original reference images and build brief
- `replit.md`, `package.json`, `pnpm-workspace.yaml`, `tsconfig*.json` — workspace configuration

The archive intentionally excludes `node_modules`, build output, caches, Git metadata, generated TypeScript build-info files, and all environment/secret values. The current app uses local typed data and does not require a database to run the frontend.
